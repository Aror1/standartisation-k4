namespace standartisation;

class GuessWord
{
    public static void Run()
    {
        Console.WriteLine("=== УГАДАЙ СЛОВО ===\n");

        string word = "КОМПЬЮТЕР";
        char[] display = new char[word.Length];
        for (int i = 0; i < display.Length; i++)
            display[i] = '_';

        bool[] guessed = new bool[word.Length];
        int attemptsLeft = word.Length;

        Console.WriteLine($"Загадано слово из {word.Length} букв.");
        Console.WriteLine($"Попыток: {attemptsLeft}\n");

        while (attemptsLeft > 0)
        {
            Console.Write("Слово: ");
            foreach (char ch in display) Console.Write(ch + " ");
            Console.WriteLine();
            Console.WriteLine($"Осталось попыток: {attemptsLeft}\n");

            bool allGuessed = true;
            foreach (char ch in display)
                if (ch == '_') { allGuessed = false; break; }
            if (allGuessed) break;

            Console.Write("Введите букву: ");
            string input = Console.ReadLine();
            if (string.IsNullOrEmpty(input))
            {
                Console.WriteLine("Пустой ввод.");
                continue;
            }
            char letter = input.ToUpper()[0];

            bool found = false;
            for (int i = 0; i < word.Length; i++)
            {
                if (word[i] == letter && !guessed[i])
                {
                    display[i] = letter;
                    guessed[i] = true;
                    found = true;
                }
            }

            if (!found)
            {
                Console.WriteLine("Такой буквы нет!");
                attemptsLeft--;
            }
            else
            {
                Console.WriteLine("Верно!");
                attemptsLeft = 0;
                foreach (char ch in display)
                    if (ch == '_') attemptsLeft++;
            }
            Console.WriteLine();
        }

        Console.Write("Слово: ");
        foreach (char ch in display) Console.Write(ch + " ");
        Console.WriteLine("\n");

        bool won = true;
        foreach (char ch in display)
            if (ch == '_') { won = false; break; }

        if (won)
            Console.WriteLine("Поздравляем! Вы угадали слово!");
        else
            Console.WriteLine($"Увы, не угадали. Слово было: {word}");

        Program.Pause();
    }
}