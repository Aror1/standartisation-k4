namespace standartisation;

class Quiz
{
    public static void Run()
    {
        Console.WriteLine("=== ВИКТОРИНА ===\n");

        string[] questions = {
            "Какова скорость света в вакууме?",
            "Какой элемент имеет химическую формулу H2O?",
            "Сколько планет в солнечной системе?"
        };

        string[][] options = {
            new[] { "300 км/с", "300 000 км/с", "3 000 км/с" },
            new[] { "Кислород", "Водород", "Вода" },
            new[] { "7", "9", "8" }
        };

        int[] correctAnswers = { 1, 2, 2 };
        int score = 0;

        for (int i = 0; i < questions.Length; i++)
        {
            Console.WriteLine($"Вопрос {i + 1}: {questions[i]}");
            for (int j = 0; j < options[i].Length; j++)
                Console.WriteLine($"  {j + 1}) {options[i][j]}");

            Console.Write("Ваш ответ (1/2/3): ");
            if (!int.TryParse(Console.ReadLine(), out int ans) || ans < 1 || ans > 3)
            {
                Console.WriteLine("Некорректный ввод. Пропуск вопроса.");
                continue;
            }
            int answer = ans - 1;

            if (answer == correctAnswers[i])
            {
                Console.WriteLine("Верно!\n");
                score++;
            }
            else
            {
                Console.WriteLine($"Неверно! Правильный ответ: {options[i][correctAnswers[i]]}\n");
            }
        }

        Console.WriteLine($"--- Результат: {score} из {questions.Length} ---");
        if (score == 3)
            Console.WriteLine("Оценка: Отлично!");
        else if (score == 2)
            Console.WriteLine("Оценка: Хорошо!");
        else
            Console.WriteLine("Оценка: Нужно повторить материал.");

        Program.Pause();
    }
}