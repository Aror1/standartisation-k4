namespace standartisation;

class QuadraticEq
{
    public static void Run()
    {
        Console.WriteLine("=== РЕШЕНИЕ КВАДРАТНОГО УРАВНЕНИЯ ===\n");
        
        double[] A = { 1, 1, 1 };
        double[] B = { -3, -2, 2 };
        double[] C = { 2, 1, 5 };

        for (int i = 0; i < A.Length; i++)
        {
            double a = A[i], b = B[i], c = C[i];
            Console.WriteLine($"--- Уравнение: {a}x² + {b}x + {c} = 0 ---");

            double D = b * b - 4 * a * c;
            Console.WriteLine($"D = {D}");

            if (D > 0)
            {
                double x1 = (-b + Math.Sqrt(D)) / (2 * a);
                double x2 = (-b - Math.Sqrt(D)) / (2 * a);
                Console.WriteLine($"Два корня: x1 = {x1}, x2 = {x2}");
            }
            else if (D == 0)
            {
                double x1 = -b / (2 * a);
                Console.WriteLine($"Один корень: x = {x1}");
            }
            else
            {
                Console.WriteLine("Корней нет (D < 0)");
            }
            Console.WriteLine();
        }

        Program.Pause();
    }
}