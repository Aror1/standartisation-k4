namespace standartisation;

class BubbleSort
{
    public static void Run()
    {
        Console.WriteLine("=== СОРТИРОВКА ПУЗЫРЬКОВЫМ МЕТОДОМ ===\n");

        int[] array = { 64, 34, 25, 12, 22, 11, 90 };

        Console.Write("До сортировки:  ");
        PrintArray(array);

        int n = array.Length;
        for (int i = 0; i < n - 1; i++)
        {
            for (int j = 0; j < n - i - 1; j++)
            {
                if (array[j] > array[j + 1])
                {
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                }
            }
            Console.Write($"Проход {i + 1}:        ");
            PrintArray(array);
        }

        Console.Write("После сортировки: ");
        PrintArray(array);

        Program.Pause();
    }

    static void PrintArray(int[] arr)
    {
        foreach (int num in arr)
            Console.Write(num + " ");
        Console.WriteLine();
    }
}