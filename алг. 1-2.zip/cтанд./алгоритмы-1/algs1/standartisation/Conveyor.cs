namespace standartisation;

using System.Threading;

class Conveyor
{
    public static void Run()
    {
        Console.WriteLine("=== КОНВЕЙЕР СБОРКИ БУТЕРБРОДА ===\n");

        string[] stages = {
            "Кладём хлеб",
            "Намазываем масло",
            "Укладываем сыр",
            "Укладываем ветчину",
            "Кладём второй кусок хлеба"
        };

        bool allOk = true;

        for (int i = 0; i < stages.Length; i++)
        {
            Console.WriteLine($"[Этап {i + 1}/{stages.Length}] {stages[i]}...");
            Thread.Sleep(1200);
            
            Console.WriteLine($"  ✓ Этап {i + 1} завершён успешно.\n");
        }

        Console.WriteLine("=============================");
        Console.WriteLine(" ПРОВЕРКА КАЧЕСТВА ");
        Console.WriteLine("=============================");
        Thread.Sleep(1500);

        Console.WriteLine("  Хлеб?      ✓");
        Console.WriteLine("  Масло?     ✓");
        Console.WriteLine("  Сыр?       ✓");
        Console.WriteLine("  Ветчина?   ✓");
        Console.WriteLine("  Крышка?    ✓");
        Console.WriteLine("=============================");
        Console.WriteLine("  Качество: ПРОВЕРЕНО ✓");
        Console.WriteLine("  Бутерброд готов к подаче!");
        Console.WriteLine("=============================");

        Program.Pause();
    }
}