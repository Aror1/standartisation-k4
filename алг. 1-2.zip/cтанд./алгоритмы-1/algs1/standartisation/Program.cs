﻿using System;
using standartisation;

class Program
{
    static void Main()
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine("МЕНЮ ПРОГРАММ");
            Console.WriteLine("1. Поиск в массиве");
            Console.WriteLine("2. Сортировка (Bubble Sort)");
            Console.WriteLine("3. Банкомат");
            Console.WriteLine("4. Квадратное уравнение");
            Console.WriteLine("5. Викторина");
            Console.WriteLine("6. Угадай слово");
            Console.WriteLine("7. Лифт");
            Console.WriteLine("8. Конвейер сборки");
            Console.WriteLine("0. Выход");
            Console.Write("\nВыберите программу: ");

            string choice = Console.ReadLine();
            Console.Clear();

            switch (choice)
            {
                case "1": SearchInArray.Run(); break;
                case "2": BubbleSort.Run(); break;
                case "3": ATM.Run(); break;
                case "4": QuadraticEq.Run(); break;
                case "5": Quiz.Run(); break;
                case "6": GuessWord.Run(); break;
                case "7": Elevator.Run(); break;
                case "8": Conveyor.Run(); break;
                case "0": return;
                default:
                    Console.WriteLine("Неверный выбор.");
                    Pause();
                    break;
            }
        }
    }

    public static void Pause()
    {
        Console.WriteLine("\nНажмите Enter для возврата...");
        Console.ReadLine();
    }
}