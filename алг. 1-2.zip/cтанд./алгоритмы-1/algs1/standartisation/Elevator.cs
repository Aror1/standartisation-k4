namespace standartisation;

using System.Threading;

class Elevator
{
    public static void Run()
    {
        Console.WriteLine("=== ЛИФТ (9 этажей) ===\n");

        int currentFloor = 1;
        Console.WriteLine($"Лифт сейчас на этаже: {currentFloor}");
        Console.Write("Введите целевой этаж (1-9): ");
        if (!int.TryParse(Console.ReadLine(), out int targetFloor) || targetFloor < 1 || targetFloor > 9)
        {
            Console.WriteLine("Неверный этаж!");
            Program.Pause();
            return;
        }

        if (targetFloor == currentFloor)
        {
            Console.WriteLine("Вы уже на нужном этаже!");
            Program.Pause();
            return;
        }

        int direction = targetFloor > currentFloor ? 1 : -1;
        string dirName = direction == 1 ? "вверх ↑" : "вниз ↓";

        Console.WriteLine($"\nНаправление движения: {dirName}");
        Console.WriteLine("Открываем двери...");
        Thread.Sleep(1000);
        Console.WriteLine("Двери открыты. Заходите!");
        Thread.Sleep(1000);
        Console.WriteLine("Закрываем двери...");
        Thread.Sleep(1000);
        Console.WriteLine("Двери закрыты. Начинаем движение.\n");
        Thread.Sleep(500);

        while (currentFloor != targetFloor)
        {
            currentFloor += direction;
            Console.WriteLine($"  Текущий этаж: {currentFloor}");
            Thread.Sleep(800);
        }

        Console.WriteLine("\nОткрываем двери...");
        Thread.Sleep(1000);
        Console.WriteLine("Двери открыты. Вы на этаже " + currentFloor + "!");

        Program.Pause();
    }
}