namespace standartisation;

class ATM
{
    public static void Run()
    {
        Console.WriteLine("=== БАНКОМАТ ===\n");

        double balance = 5000;
        double limit = 3000;

        Console.WriteLine($"Остаток на счёте: {balance} руб.");
        Console.WriteLine($"Лимит снятия:     {limit} руб.\n");

        Console.Write("Введите сумму для снятия: ");
        if (!double.TryParse(Console.ReadLine(), out double amount))
        {
            Console.WriteLine("Некорректная сумма.");
            Program.Pause();
            return;
        }

        if (amount % 100 != 0)
        {
            Console.WriteLine("Ошибка: сумма должна быть кратна 100.");
        }
        else if (amount > limit)
        {
            Console.WriteLine($"Ошибка: сумма превышает лимит ({limit} руб.).");
        }
        else if (amount > balance)
        {
            Console.WriteLine("Ошибка: недостаточно средств.");
        }
        else
        {
            balance -= amount;
            Console.WriteLine("Заберите деньги!");
            Console.WriteLine($"Новый остаток: {balance} руб.");
        }

        Program.Pause();
    }
}