class SearchInArray
{
    public static void Run()
    {
        Console.WriteLine("=== ПОИСК В МАССИВЕ ===\n");
        
        int[] array = { 15, 3, 27, 8, 42, 11, 56, 99, 7, 23 };

        Console.Write("Массив: ");
        foreach (int num in array)
            Console.Write(num + " ");
        Console.WriteLine("\n");

        Console.Write("Введите искомое число X: ");
        if (!int.TryParse(Console.ReadLine(), out int x))
        {
            Console.WriteLine("Некорректный ввод.");
            Program.Pause();
            return;
        }
        
        int index = -1;
        for (int i = 0; i < array.Length; i++)
        {
            if (array[i] == x)
            {
                index = i;
                break;
            }
        }

        if (index != -1)
            Console.WriteLine($"Число {x} найдено на индексе {index}");
        else
            Console.WriteLine("Не найдено");

        Program.Pause();
    }
}